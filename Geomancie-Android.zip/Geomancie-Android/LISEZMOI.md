# Géomancie — application Android

Ce dossier est un projet Android complet : l'application (`app/src/main/assets/index.html`)
est affichée dans une WebView, fonctionne **hors ligne** et s'adapte aux téléphones, tablettes,
pliables, mode paysage et écrans à encoche.

## Obtenir l'APK — Méthode 1 : GitHub (sans rien installer)
1. Crée un compte gratuit sur github.com, puis un nouveau dépôt (New repository).
2. Envoie TOUT le contenu de ce dossier dans le dépôt (« Add file » → « Upload files »),
   sans oublier le dossier caché `.github`. Si ton navigateur ne l'envoie pas, crée à la main le fichier
   `.github/workflows/build-apk.yml` (« Add file » → « Create new file ») et colle son contenu.
3. Ouvre l'onglet **Actions** → « Construire l'APK » → **Run workflow** (ou attends l'exécution automatique).
4. Quand c'est vert, ouvre l'exécution et télécharge l'artefact **geomancie-apk** (zip contenant `app-debug.apk`).
5. Sur le téléphone : ouvre l'APK et autorise « Installer des applications inconnues » pour ton navigateur ou ton gestionnaire de fichiers.

## Méthode 2 : Android Studio (ordinateur)
1. Installe Android Studio (JDK 17 inclus).
2. File → Open → choisis ce dossier, attends la synchronisation Gradle.
3. Build → Build Bundle(s) / APK(s) → **Build APK(s)**.
4. L'APK est dans `app/build/outputs/apk/debug/app-debug.apk`.

## Notes
- L'APK « debug » est signé avec la clé de test : il s'installe sur n'importe quel téléphone, mais ne convient pas au Play Store.
  Pour publier : Build → Generate Signed Bundle / APK dans Android Studio.
- Android 8.0 ou plus récent (minSdk 26). Aucune permission demandée.
- Pour modifier l'appli, remplace `app/src/main/assets/index.html`.
